import csv

USUARIOS_FILE = 'usuarios.csv'

def cargar_usuarios():
    """Lee y carga todos los usuarios desde el archivo CSV."""
    usuarios = []
    try:
        with open(USUARIOS_FILE, mode='r', newline='', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                usuarios.append(row)
    except FileNotFoundError:
        print(f"Error: El archivo {USUARIOS_FILE} no se encontró.")
    return usuarios

def validar_credenciales(usuario, contrasena):
    """Valida el usuario y contraseña contra el CSV."""
    usuarios = cargar_usuarios()
    for user in usuarios:
        if user['usuario'] == usuario and user['contrasena'] == contrasena:
            # Retorna el rol si las credenciales son correctas
            return user['rol']
    return None