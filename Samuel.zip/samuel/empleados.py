import csv
import os
from datetime import datetime
from vacaciones import calcular_dias_disponibles # Importamos para mostrar saldo

EMPLEADOS_FILE = 'empleados.csv'

def cargar_empleados():
    """Lee y carga todos los empleados desde el archivo CSV."""
    empleados = []
    try:
        with open(EMPLEADOS_FILE, mode='r', newline='', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                empleados.append(row)
    except FileNotFoundError:
        # Crea el archivo con encabezado si no existe
        guardar_empleados([])
    return empleados

def guardar_empleados(empleados):
    """Escribe la lista completa de empleados en el CSV."""
    fieldnames = ['empleado_id', 'nombre_completo', 'cargo', 'area', 'fecha_inicio_contrato', 'experiencia']
    with open(EMPLEADOS_FILE, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(empleados)

def generar_id(empleados):
    """Genera un nuevo ID secuencial."""
    if not empleados:
        return 1
    # Obtiene el ID más alto y suma 1
    return max(int(emp['empleado_id']) for emp in empleados) + 1

def registrar_empleado():
    """Solicita y guarda un nuevo empleado."""
    empleados = cargar_empleados()
    empleado_id = generar_id(empleados)
    print("\n--- Registro de Nuevo Empleado ---")
    nombre_completo = input("Nombre completo: ")
    cargo = input("Cargo: ")
    area = input("Área: ")
    
    # Validación simple de fecha
    while True:
        try:
            fecha_inicio = input("Fecha de inicio de contrato (AAAA-MM-DD): ")
            datetime.strptime(fecha_inicio, '%Y-%m-%d')
            break
        except ValueError:
            print("Formato de fecha incorrecto. Use AAAA-MM-DD.")

    experiencia = input("Años de experiencia (Opcional, dejar vacío si no aplica): ")

    nuevo_empleado = {
        'empleado_id': str(empleado_id),
        'nombre_completo': nombre_completo,
        'cargo': cargo,
        'area': area,
        'fecha_inicio_contrato': fecha_inicio,
        'experiencia': experiencia
    }
    
    empleados.append(nuevo_empleado)
    guardar_empleados(empleados)
    print(f"\n✅ Empleado {nombre_completo} (ID: {empleado_id}) registrado con éxito.")

def listar_empleados():
    """Muestra un resumen de todos los empleados."""
    empleados = cargar_empleados()
    if not empleados:
        print("\nNo hay empleados registrados.")
        return

    print("\n--- Listado de Empleados ---")
    print(f"{'ID':<5} | {'Nombre Completo':<30} | {'Cargo':<20} | {'Área':<15}")
    print("-" * 75)
    for emp in empleados:
        print(f"{emp['empleado_id']:<5} | {emp['nombre_completo']:<30} | {emp['cargo']:<20} | {emp['area']:<15}")

def consultar_empleado():
    """Muestra toda la información de un empleado específico, incluyendo saldo de vacaciones."""
    empleado_id = input("Ingrese el ID del empleado a consultar: ")
    empleados = cargar_empleados()
    
    for emp in empleados:
        if emp['empleado_id'] == empleado_id:
            dias_disponibles = calcular_dias_disponibles(empleado_id)
            
            print("\n--- Información Detallada del Empleado ---")
            print(f"ID: {emp['empleado_id']}")
            print(f"Nombre: {emp['nombre_completo']}")
            print(f"Cargo: {emp['cargo']}")
            print(f"Área: {emp['area']}")
            print(f"Fecha Inicio Contrato: {emp['fecha_inicio_contrato']}")
            print(f"Años Experiencia: {emp['experiencia'] if emp['experiencia'] else 'N/A'}")
            print("-" * 40)
            print(f"**Días de Vacaciones Disponibles:** {dias_disponibles:.2f} días")
            print("-" * 40)
            return

    print(f"\n❌ Error: No se encontró ningún empleado con ID {empleado_id}.")