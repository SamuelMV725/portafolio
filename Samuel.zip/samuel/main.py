import usuarios
import empleados
import vacaciones
import reportes

def menu_gestion_empleados():
    """Menú para la Gestión de Empleados."""
    while True:
        print("\n--- Menú de Gestión de Empleados ---")
        print("1. Registrar nuevo empleado")
        print("2. Listar todos los empleados")
        print("3. Consultar un empleado (Ver saldo de vacaciones)")
        print("4. Volver al Menú Principal")
        
        opcion = input("Seleccione una opción: ")
        
        if opcion == '1':
            empleados.registrar_empleado()
        elif opcion == '2':
            empleados.listar_empleados()
        elif opcion == '3':
            empleados.consultar_empleado()
        elif opcion == '4':
            break
        else:
            print("Opción no válida. Intente de nuevo.")

def menu_gestion_vacaciones():
    """Menú para Solicitud y Aprobación de Vacaciones."""
    while True:
        print("\n--- Menú de Solicitud y Aprobación de Vacaciones ---")
        print("1. Registrar solicitud de vacaciones")
        print("2. Aprobar/Rechazar solicitudes pendientes")
        print("3. Ver historial de solicitudes de un empleado")
        print("4. Volver al Menú Principal")
        
        opcion = input("Seleccione una opción: ")
        
        if opcion == '1':
            vacaciones.registrar_solicitud()
        elif opcion == '2':
            vacaciones.aprobar_o_rechazar_solicitud()
        elif opcion == '3':
            vacaciones.historial_solicitudes()
        elif opcion == '4':
            break
        else:
            print("Opción no válida. Intente de nuevo.")

def menu_principal(rol):
    """Menú principal del sistema."""
    while True:
        print("\n=====================================")
        print("=== PeopleOps Vacation Console RIWI ===")
        print(f"Usuario: {rol}")
        print("=====================================")
        print("1. Gestión de Empleados (Registro/Consulta)")
        print("2. Solicitud y Aprobación de Vacaciones")
        print("3. Exportar Reporte CSV (Solicitudes APROBADAS)")
        print("4. Salir")
        
        opcion = input("Seleccione una opción: ")
        
        if opcion == '1':
            menu_gestion_empleados()
        elif opcion == '2':
            menu_gestion_vacaciones()
        elif opcion == '3':
            reportes.generar_reporte_csv()
        elif opcion == '4':
            print("\n👋 Cerrando aplicación. ¡Hasta pronto!")
            break
        else:
            print("Opción no válida. Intente de nuevo.")

def inicio_sesion():
    """Maneja el inicio de sesión y el acceso al menú principal."""
    MAX_INTENTOS = 3
    intentos = 0
    
    print("\n=====================================")
    print("=== INICIO DE SESIÓN RIWI =====")
    print("=====================================")

    while intentos < MAX_INTENTOS:
        usuario = input("Usuario: ")
        contrasena = input("Contraseña: ")
        
        rol = usuarios.validar_credenciales(usuario, contrasena)
        
        if rol:
            print(f"\nBienvenido, {usuario} ({rol}).")
            menu_principal(rol)
            return # Sale de la función después de cerrar sesión
        else:
            intentos += 1
            restantes = MAX_INTENTOS - intentos
            if restantes > 0:
                print(f"❌ Credenciales incorrectas. Le quedan {restantes} intentos.")
            else:
                print("\n❌ Ha agotado sus intentos. Cerrando aplicación.")
                
if __name__ == "__main__":
    inicio_sesion()