import csv
import os
from empleados import cargar_empleados
from vacaciones import cargar_solicitudes

def generar_reporte_csv():
    """Genera un archivo CSV con solicitudes APROBADAS para un mes y año dados."""
    print("\n--- Generación de Reporte CSV ---")
    
    while True:
        try:
            mes = int(input("Ingrese el número del mes (1-12) para el reporte: "))
            if 1 <= mes <= 12:
                break
            print("Mes inválido. Debe ser entre 1 y 12.")
        except ValueError:
            print("Entrada no válida. Ingrese un número.")

    while True:
        try:
            anio = int(input("Ingrese el año (ej: 2025) para el reporte: "))
            if anio >= 2000: # Asumimos un rango razonable
                break
            print("Año inválido.")
        except ValueError:
            print("Entrada no válida. Ingrese un número.")
            
    empleados = cargar_empleados()
    solicitudes = cargar_solicitudes()
    
    # Filtrar solicitudes APROBADAS y por mes/año
    reporte_data = []
    empleados_dict = {emp['empleado_id']: emp for emp in empleados}

    for sol in solicitudes:
        if sol['estado'] == 'APROBADA' and int(sol['mes']) == mes and int(sol['anio']) == anio:
            emp_id = sol['empleado_id']
            if emp_id in empleados_dict:
                emp_info = empleados_dict[emp_id]
                
                reporte_row = {
                    'empleado_id': emp_id,
                    'nombre_empleado': sol['nombre_empleado'],
                    'cargo': emp_info['cargo'],
                    'area': emp_info['area'],
                    'fecha_inicio_vacaciones': sol['fecha_inicio_vacaciones'],
                    'fecha_fin_vacaciones': sol['fecha_fin_vacaciones'],
                    'dias_calculados': sol['dias_calculados'],
                    'mes': sol['mes'],
                    'anio': sol['anio']
                }
                reporte_data.append(reporte_row)

    # Generar el archivo CSV
    nombre_archivo = f"reporte_vacaciones_{anio}_{mes:02d}.csv"
    fieldnames = ['empleado_id', 'nombre_empleado', 'cargo', 'area', 
                  'fecha_inicio_vacaciones', 'fecha_fin_vacaciones', 
                  'dias_calculados', 'mes', 'anio']
                  
    if not reporte_data:
        print(f"\n⚠️ No se encontraron solicitudes APROBADAS para {mes:02d}/{anio}. No se generó el archivo.")
        return

    try:
        with open(nombre_archivo, mode='w', newline='', encoding='utf-8') as file:
            writer = csv.DictWriter(file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(reporte_data)
        
        print(f"\n🎉 ¡Reporte generado con éxito!")
        print(f"Archivo: **{nombre_archivo}** (Contiene {len(reporte_data)} registros).")
    except Exception as e:
        print(f"❌ Error al escribir el archivo: {e}")