import csv
from datetime import datetime, timedelta
import os
import math

VACACIONES_FILE = 'vacaciones.csv'
DIAS_ACUMULACION_MENSUAL = 1.5
MESES_MINIMOS_CONTRATO = 6

# --- Funciones de Persistencia ---

def cargar_solicitudes():
    """Lee y carga todas las solicitudes desde el archivo CSV."""
    solicitudes = []
    try:
        with open(VACACIONES_FILE, mode='r', newline='', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                solicitudes.append(row)
    except FileNotFoundError:
        # Crea el archivo con encabezado si no existe
        guardar_solicitudes([])
    return solicitudes

def guardar_solicitudes(solicitudes):
    """Escribe la lista completa de solicitudes en el CSV."""
    fieldnames = ['empleado_id', 'nombre_empleado', 'fecha_inicio_vacaciones', 
                  'fecha_fin_vacaciones', 'dias_calculados', 'estado', 'mes', 'anio']
    with open(VACACIONES_FILE, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(solicitudes)

# --- Funciones de Regla de Negocio (RIWI) ---

def calcular_meses_completos(fecha_inicio_str):
    """Calcula los meses completos trabajados desde la fecha de inicio hasta hoy."""
    try:
        fecha_inicio = datetime.strptime(fecha_inicio_str, '%Y-%m-%d').date()
    except ValueError:
        return 0 # Fecha de inicio inválida

    hoy = datetime.now().date()
    
    # Si la fecha de inicio es futura, retorna 0
    if fecha_inicio > hoy:
        return 0
    
    meses_totales = (hoy.year - fecha_inicio.year) * 12 + (hoy.month - fecha_inicio.month)
    
    # Verificar si el día del mes actual es mayor o igual al día de inicio (para contar el mes completo)
    if hoy.day < fecha_inicio.day:
        meses_totales -= 1
        
    return max(0, meses_totales)

def calcular_dias_disponibles(empleado_id):
    """
    Calcula los días disponibles: (meses_completos * 1.5) - (días ya aprobados).
    Requiere una función externa para obtener la fecha de inicio del empleado.
    """
    from empleados import cargar_empleados # Importación local para evitar dependencia circular
    empleados = cargar_empleados()
    
    empleado = next((emp for emp in empleados if emp['empleado_id'] == empleado_id), None)
    if not empleado:
        return 0.0

    fecha_inicio = empleado['fecha_inicio_contrato']
    meses_completos = calcular_meses_completos(fecha_inicio)
    
    dias_acumulados = meses_completos * DIAS_ACUMULACION_MENSUAL
    
    solicitudes = cargar_solicitudes()
    dias_aprobados = 0
    
    # Sumar días de solicitudes APROBADAS
    for sol in solicitudes:
        if sol['empleado_id'] == empleado_id and sol['estado'] == 'APROBADA':
            dias_aprobados += float(sol['dias_calculados'])
            
    return dias_acumulados - dias_aprobados

def validar_antiguedad(fecha_inicio_str):
    """Retorna True si el empleado tiene al menos 6 meses completos trabajados."""
    meses = calcular_meses_completos(fecha_inicio_str)
    return meses >= MESES_MINIMOS_CONTRATO

def contar_dias_solicitados(fecha_inicio_str, fecha_fin_str):
    """Cuenta los días solicitados entre inicio y fin, excluyendo domingos."""
    try:
        fecha_inicio = datetime.strptime(fecha_inicio_str, '%Y-%m-%d')
        fecha_fin = datetime.strptime(fecha_fin_str, '%Y-%m-%d')
    except ValueError:
        return 0, False

    if fecha_inicio > fecha_fin:
        return 0, False

    dias_contados = 0
    fecha_actual = fecha_inicio
    
    while fecha_actual <= fecha_fin:
        # weekday() donde 0 es Lunes y 6 es Domingo
        if fecha_actual.weekday() != 6: # 6 es Domingo
            dias_contados += 1
        fecha_actual += timedelta(days=1)
        
    return dias_contados, True

# --- Funcionalidad de Solicitud y Aprobación ---

def registrar_solicitud():
    """Proceso guiado para registrar una solicitud de vacaciones."""
    from empleados import cargar_empleados # Importación local
    empleados = cargar_empleados()

    empleado_id = input("Ingrese el ID del empleado que solicita vacaciones: ")
    empleado = next((emp for emp in empleados if emp['empleado_id'] == empleado_id), None)
    
    if not empleado:
        print(f"\n❌ Error: Empleado con ID {empleado_id} no encontrado.")
        return

    # 1. Validar que tenga +6 meses trabajados
    if not validar_antiguedad(empleado['fecha_inicio_contrato']):
        print(f"\n❌ El empleado {empleado['nombre_completo']} aún no cumple los {MESES_MINIMOS_CONTRATO} meses de antigüedad para solicitar vacaciones.")
        return
        
    # 2. Validar fechas y calcular días
    while True:
        fecha_inicio_str = input("Fecha de inicio de vacaciones (AAAA-MM-DD): ")
        fecha_fin_str = input("Fecha de fin de vacaciones (AAAA-MM-DD): ")
        
        dias_solicitados, valido = contar_dias_solicitados(fecha_inicio_str, fecha_fin_str)
        
        if not valido:
            print("❌ Error en el formato de fecha o fecha de inicio posterior a la de fin. Intente de nuevo.")
            continue
            
        print(f"Calculado: Se solicitan {dias_solicitados} días (sin contar domingos).")
        
        # 3. Validar que los días solicitados no superen los disponibles
        dias_disponibles = calcular_dias_disponibles(empleado_id)
        print(f"Saldo disponible: {dias_disponibles:.2f} días.")
        
        if dias_solicitados > dias_disponibles:
            print(f"\n❌ Error: Los {dias_solicitados} días solicitados superan el saldo disponible de {dias_disponibles:.2f} días.")
            return

        break # Si las fechas son válidas y el saldo es suficiente

    # 4. Guardar solicitud con estado PENDIENTE
    solicitudes = cargar_solicitudes()
    
    try:
        fecha_inicio_dt = datetime.strptime(fecha_inicio_str, '%Y-%m-%d')
    except ValueError:
        # Esto no debería pasar debido al bucle de validación, pero por seguridad
        print("Error interno de fecha.")
        return

    nueva_solicitud = {
        'empleado_id': empleado_id,
        'nombre_empleado': empleado['nombre_completo'],
        'fecha_inicio_vacaciones': fecha_inicio_str,
        'fecha_fin_vacaciones': fecha_fin_str,
        'dias_calculados': str(dias_solicitados),
        'estado': 'PENDIENTE',
        'mes': str(fecha_inicio_dt.month),
        'anio': str(fecha_inicio_dt.year)
    }
    
    solicitudes.append(nueva_solicitud)
    guardar_solicitudes(solicitudes)
    print(f"\n✅ Solicitud registrada para {empleado['nombre_completo']} por {dias_solicitados} días. Estado: PENDIENTE.")

def listar_solicitudes_pendientes():
    """Muestra todas las solicitudes pendientes."""
    solicitudes = cargar_solicitudes()
    pendientes = [sol for sol in solicitudes if sol['estado'] == 'PENDIENTE']
    
    if not pendientes:
        print("\nNo hay solicitudes de vacaciones PENDIENTES.")
        return []

    print("\n--- Solicitudes PENDIENTES ---")
    print(f"{'Num':<4} | {'ID Emp':<7} | {'Nombre':<25} | {'Inicio':<12} | {'Fin':<12} | {'Días':<5}")
    print("-" * 65)
    
    for i, sol in enumerate(pendientes):
        print(f"{i+1:<4} | {sol['empleado_id']:<7} | {sol['nombre_empleado']:<25} | {sol['fecha_inicio_vacaciones']:<12} | {sol['fecha_fin_vacaciones']:<12} | {sol['dias_calculados']:<5}")
        
    return pendientes

def aprobar_o_rechazar_solicitud():
    """Permite al administrador aprobar o rechazar solicitudes pendientes."""
    pendientes = listar_solicitudes_pendientes()
    if not pendientes:
        return

    try:
        opcion_num = int(input("\nIngrese el número (Num) de la solicitud a gestionar: "))
        if 1 <= opcion_num <= len(pendientes):
            solicitud_a_gestionar = pendientes[opcion_num - 1]
            
            accion = input("¿Desea (A)probar o (R)echazar? (A/R): ").upper()
            
            if accion == 'A':
                nuevo_estado = 'APROBADA'
                print("\n✅ Solicitud APROBADA. Los días se descontarán del balance acumulado.")
            elif accion == 'R':
                nuevo_estado = 'RECHAZADA'
                print("\n❌ Solicitud RECHAZADA. No afecta el balance acumulado.")
            else:
                print("Opción no válida. Volviendo al menú.")
                return

            # Actualizar el estado en la lista completa de solicitudes
            solicitudes = cargar_solicitudes()
            for sol in solicitudes:
                # La forma más simple de identificarla: por empleado, inicio y fin (asumiendo que son únicos para PENDIENTES)
                if (sol['empleado_id'] == solicitud_a_gestionar['empleado_id'] and 
                    sol['fecha_inicio_vacaciones'] == solicitud_a_gestionar['fecha_inicio_vacaciones'] and 
                    sol['estado'] == 'PENDIENTE'): # Solo actualiza si aún está PENDIENTE
                    
                    sol['estado'] = nuevo_estado
                    break
            
            guardar_solicitudes(solicitudes)
            
        else:
            print("Número de solicitud no válido.")
    except ValueError:
        print("Entrada no válida.")

def historial_solicitudes():
    """Muestra todas las solicitudes (todos los estados) de un empleado."""
    empleado_id = input("Ingrese el ID del empleado para ver su historial de solicitudes: ")
    solicitudes = cargar_solicitudes()
    
    historial = [sol for sol in solicitudes if sol['empleado_id'] == empleado_id]
    
    if not historial:
        print(f"\nNo hay historial de solicitudes para el ID {empleado_id}.")
        return

    print(f"\n--- Historial de Solicitudes para ID: {empleado_id} ---")
    print(f"{'Inicio':<12} | {'Fin':<12} | {'Días':<5} | {'Estado':<10} | {'Periodo':<7}")
    print("-" * 50)
    
    for sol in historial:
        print(f"{sol['fecha_inicio_vacaciones']:<12} | {sol['fecha_fin_vacaciones']:<12} | {sol['dias_calculados']:<5} | {sol['estado']:<10} | {sol['mes']}/{sol['anio']}")